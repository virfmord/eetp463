<?php
return array(
    "driver"    =>"mysql",
    "host"      =>"localhost",
    "user"      =>"root",
    "pass"      =>"",
    "database"  =>"pruebas",
    "charset"   =>"utf8"
);
?>
